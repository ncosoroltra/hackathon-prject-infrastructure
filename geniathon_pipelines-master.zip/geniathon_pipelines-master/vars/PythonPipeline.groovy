
/**
    * Defines the pipeline stages and executes them in a Jenkins node.
    * Handles any exceptions that occur during the pipeline.
    */
def call() {
    
    pipeline {
        node {
            checkout scm
            
            stage('Install dependencies') {
                sh 'pip install -r requirements.txt'
            }
                

            stage('Run tests') {
                sh 'coverage run -m unittest discover -s tests'
                sh 'coverage report -m'
            }

            stage('SonarQube analysis') {
                withSonarQubeEnv('SonarQube') {
                    sh 'sonar-scanner'
                }
            }

            stage('Quality Gate') {
                timeout(time: 1, unit: 'HOURS') {
                    waitForQualityGate abortPipeline: true
                }
            }
        }
    }
}
