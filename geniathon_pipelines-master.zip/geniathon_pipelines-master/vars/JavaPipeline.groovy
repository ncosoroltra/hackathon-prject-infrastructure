
/**
    * Defines the pipeline stages and executes them in a Jenkins node.
    * Handles any exceptions that occur during the pipeline.
    */
def call() {
    pipeline {
         
        node {
            echo "Checking out code...branch: ${env.BRANCH_NAME}"
            checkout scm
            def mavenInfo = readMavenPom file: 'pom.xml'            
            echo "${mavenInfo}"
            
            def USERNAME = env.BRANCH_NAME
            def TYPE = 'manual'

            if (env.BRANCH_NAME.split('_').length == 2) {
                USERNAME =  env.BRANCH_NAME.split('_')[0]
                def temp = env.BRANCH_NAME.split('_')[1]

                if(temp.toLowerCase().contains('copilot'))
                    TYPE = 'copilot'
            } else {
                USERNAME = env.BRANCH_NAME
                TYPE = 'manual'
            }
            

            try {

                stage('Build Project') {
                    try {
                        echo 'Construyendo proyeto...'
                        withMaven(maven: 'maven-3.9.5') {
                            sh 'mvn clean package'
                        }
                        echo 'Construcción finalizada!'
                     } catch (Exception e) {
                        echo "Error during unit tests: ${e.getMessage()}"
                        throw e
                    }                   
                }     
   
                stage('Pruebas unitarias') {
                    try {
                        echo 'Ejecutando pruebas unitarias...'
                        withMaven(maven: 'maven-3.9.5') {
                            sh 'mvn clean test'
                        }
                        echo 'Pruebas unitarias completadas!'
                     } catch (Exception e) {
                        echo "Error during unit tests: ${e.getMessage()}"
                        throw e
                    }                   
                }         

                stage("SonarQube analysis") {                            
                    echo 'Scanning the project...'
                    withMaven (maven: 'maven-3.9.5'){
                        withSonarQubeEnv('Sonarqube') {
                            sh 'mvn clean install test sonar:sonar'
                        }
                    }
                    echo 'Scan complete!'                    
                }

                stage("Quality Gate") {                        
                    echo 'Waiting for Quality Gate...'
                    timeout(time: 1, unit: 'HOURS') {
                       def qg = waitForQualityGate()
                        if (qg.status != 'OK') {
                            echo "Quality gate fails: ${qg.status}"
                        }
                        else {
                            echo 'Quality Gate complete!'
                        }
                    }
                    
                }
 
                  
                stage('Build Docker Image') {
                    echo "Building Docker Image...  rperalta/geniathon:${USERNAME}_${TYPE} "

                    withMaven (maven: 'maven-3.9.5'){
                        sh "mvn clean package -DskipTests=true -DbranchName=${USERNAME} -DdevelopmentType=${TYPE} spring-boot:repackage"
                    }

                    docker.build("rperalta/geniathon:${USERNAME}_${TYPE}", '.')
                    
                    echo "Build Docker Image complete!"
                                      
                }

                


                stage('Performance Test') {
                    try {
                        echo "Running container...  rperalta/geniathon:${USERNAME}_${TYPE}"
                        
                       
                        docker.image("rperalta/geniathon:${USERNAME}_${TYPE}").withRun("-p 8081:8081 --name ${USERNAME} --network geniathon_alm_geniathon_network --network-alias ${USERNAME} ") { 
                                c ->
                                    echo "Container ${c.id} is running"
                                    
                                    // wait while service in localhost:8081 is up
                                    timeout(time: 1, unit: 'MINUTES') {
                                       //wait until the response of http://${USERNAME}:8081/actuator/health is UP
                                        waitUntil {
                                            try {         
                                                sh "curl -s --head --request GET ${USERNAME}:8081/actuator/health | grep '200'"
                                                echo "Service is up!"
                                                return true
                                            } catch (Exception e) {
                                                echo "Service is not up yet"
                                                return false
                                            }
                                            
                                        }
                                    }
                                    

                                    echo 'Running performance...'
                                    
                                    withMaven (maven: 'maven-3.9.5'){
                                        sh "mvn gatling:test -DserviceUrl=${USERNAME}:8081"
                                    }
                                    
                                    echo 'Performance test complete!'
                                    
                                    echo "Container ${c.id} is stopping"
                        }
                    } catch (Exception e) {
                        echo "Error during Performance tests: ${e.getMessage()}"
                        throw e
                    } finally {
                        gatlingArchive()
                        sh "docker rm -f ${USERNAME}_${TYPE}"
                        echo "Container ${USERNAME}_${TYPE} removed"
                    }
                                                
                }  
                
                
            } catch (Exception e) {
                echo "Pipeline failed: ${e.getMessage()}"
                throw e
            }
        }
    }
}
 