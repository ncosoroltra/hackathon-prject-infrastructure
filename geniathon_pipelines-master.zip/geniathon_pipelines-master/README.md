# Mi Proyecto

Este proyecto consiste en una pipeline de Jenkins escrita en Groovy que utiliza Maven como gestor de dependencias y está preparada para realizar test unitarios.

## Estructura del proyecto

El proyecto tiene la siguiente estructura de archivos:

- `src/main/groovy/MiPipeline.groovy`: Este archivo exporta una clase `MiPipeline` que define la pipeline de Jenkins. Utiliza Maven para gestionar las dependencias e incluye etapas para construir, probar y desplegar el proyecto.
- `pom.xml`: Este archivo es el archivo de configuración de Maven. Lista las dependencias y plugins del proyecto.
- `README.md`: Este archivo contiene la documentación del proyecto.

## Uso

Para ejecutar la pipeline de Jenkins, simplemente hay que ejecutar la clase `MiPipeline` en Jenkins. La pipeline se encargará de construir, probar y desplegar el proyecto.

Para ejecutar las pruebas unitarias, se puede ejecutar la clase `MiPipelineTest` en cualquier entorno de pruebas compatible con Groovy.

## Contribuir

Si quieres contribuir a este proyecto, por favor crea un pull request con tus cambios. Asegúrate de que tus cambios no rompen las pruebas unitarias existentes y de que añades pruebas unitarias para cualquier nueva funcionalidad que añadas.

## Licencia

Este proyecto está licenciado bajo la Licencia MIT. Consulta el archivo `LICENSE` para más detalles.