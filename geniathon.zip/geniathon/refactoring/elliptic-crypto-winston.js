const crypto = require('crypto');
const EC = require('elliptic').ec;


// Este es el mensaje a firmar
const message = JSON.stringify({ text: 'hello', timestamp: Date.now(), status: 'pending' });


// create elliptic curve object
const ec = new EC('secp256k1');

// generate private key
const privKey = crypto.randomBytes(32);

// sign the message
const signature = ec.sign(message, privKey);

// get the public key in a compressed format
const pubKey = ec.keyFromPrivate(privKey).getPublic('x509');

// verify the signature
const result = ec.verify(message, signature, pubKey);
// => true


const winston = require('winston');

// Configure the logger
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [
        new winston.transports.Console(),
        new winston.transports.File({ filename: 'logs.log' })
    ]
});

// Log the message, signature, private key, public key, and verification result
logger.info(`Mensaje: ${message}`);
logger.info(`Signatura secp256r1: ${signature}`);
logger.info(`Clave Privada secp256r1: ${privKey.toString('base64')}`);
logger.info(`Clave Publica secp256r1: ${pubKey}`);
logger.info(`Resultado de la verificación: ${result}`);