const ECDSA = require('ecdsa-secp256r1');

// Este es el mensaje a firmar
const message = JSON.stringify({ text: 'hello', timestamp: Date.now(), status: 'pending' });

// Generar una clave privada aleatoria
const privateKey = ECDSA.generateKey();

// Convertir la clave privada a formato JWK (JSON Web Key)
privateKey.toJWK();

// Convertir la clave pública correspondiente a la clave privada a formato JWK
privateKey.asPublic().toJWK();

// Convertir la clave privada a formato PEM (Privacy Enhanced Mail)
privateKey.toPEM();

// Convertir la clave pública correspondiente a la clave privada a formato PEM
privateKey.asPublic().toPEM();

// Convertir la clave privada a clave pública comprimida
const key = privateKey.toCompressedPublicKey();

// Convertir la clave pública comprimida a objeto clave pública
const publicKey = ECDSA.fromCompressedPublicKey(key);

// Firmar el mensaje con la clave privada
const signature = privateKey.sign(message);

// Verificar la firma del mensaje con la clave pública
const result = publicKey.verify(message, signature);

// Imprimir el mensaje, la signatura, clave pública y el resultado de la verificación de la firma
console.log(`\nMensaje: ${message}`);
console.log(`\nSignatura secp256r1: ${signature}`);
console.log(`\nClave Privada secp256r1: ${key}`);
console.log(`\nClave Publica secp256r1: ${publicKey.toPEM()}`);
console.log(`Resultado de la verificación: ${result}`);