const parser = require('swagger-parser');
const yaml = require('js-yaml');
const fs = require('fs');


var refByEndpointArray = [];
var globalApi;
//var path = "./yaml0.yaml";
var path = "./yaml1.yaml";

/**
 * Reads a YAML file, parses it into an OpenAPI object, and analyzes its endpoints and components.
 * @async
 * @function init
 * @param {string} path - The path to the YAML file.
 * @returns {Promise<void>} - A Promise that resolves when the analysis is complete.
 */
const init = async () => {
    // Read the contents of the file at the specified path
    let fileYaml = fs.readFileSync(path, 'utf8');

    // Parse the YAML contents into a JavaScript object
    const obj = yaml.load(fileYaml);

    // Parse the OpenAPI object using the parser library
    parser.parse(obj, (err, api) => {
        if (err) {
            // If an error occurs during parsing, log the error to the console
            console.error('Error al analizar el archivo OpenAPI:', err);
        } else {
            // If parsing is successful, store the resulting API object and analyze its endpoints
            globalApi = api;
            analyzeEndpoints(api.paths, api.components);
            console.log("---------------  refByEndpointArray ---------------")
            console.log(refByEndpointArray);
        }
    });
}


/**
 * Analyzes the endpoints of an API and finds references.
 * @function
 * @returns {void}
 */
const analyzeEndpoints = () => {
    for (const [path, value] of Object.entries(globalApi.paths)) {
        // Iterate over the keys and values of the `paths` object in the `api` object
        for (const method in value) {
            // Iterate over the keys of the `value` object (which represents an HTTP method)
            let endpoint = path + '.' + method;   // Create a string that represents the current endpoint (e.g. "/users.GET")
            let jsonByMethod = {};
            jsonByMethod[method] = value[method];
            findRefs(jsonByMethod, endpoint);
            // Find references in the JSON object of the endpoint, recursive method

        }
    }
}




/**
 * Finds all $ref by endpoint (ref = path + method)
 * @param {Object} obj - The object to search for $ref in
 * @param {string} endpoint - The endpoint to search for $ref in (path + method)
 */
const findRefs = (obj, endpoint) => { //find $ref by endpoint (path + method)

    // Iterate over the keys of the `obj` object
    for (const key in obj) {
        if (key === '$ref') {
            
            if (!refByEndpointArray[endpoint]) //endpoint exist?
                refByEndpointArray[endpoint] = new Set();

            // If the key is "$ref", extract the reference and save it
            let ref = obj[key];
            if (ref.substring(0, 6) != 'https:') { //Ignore external references

                refByEndpointArray[endpoint].add(ref); //save the reference in the set of the endpoint
                let arr = ref.split('/');
                if (arr.length == 4) { // e.g. #/components/schemas/object or #/components/requestbodies/object or #/components/responses/object or #/components/parameters/object
                    let type = arr[2];
                    let name = arr[3];
                    let obj2 = globalApi.components[type][name];  
                    findRefs(obj2, endpoint);
                }
                //}
            }
        } else if (typeof obj[key] === 'object') {
            // If the value of the key is an object, recursively call the `findRefs()` function
            findRefs(obj[key], endpoint);
        }
    }
}

init();