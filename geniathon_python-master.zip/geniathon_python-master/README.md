# My Python Project

This is a sample Python project that implements a simple Flask API with a `/test` route that returns the string "Hello, world!".

## Getting Started

To get started with this project, you will need to have Python 3 and pip installed on your system. You can install the project dependencies by running:

```
pip install -r requirements.txt
```

You can run the Flask app by running:

```
python src/main.py
```

You can run the unit tests by running:

```
pytest
```

You can build a Docker image for the project by running:

```
docker build -t my-python-project .
```

You can run the Docker container for the project by running:

```
docker run -p 5000:5000 my-python-project
```

You can access the API by visiting `http://localhost:5000/test` in your web browser.

## Project Structure

The project has the following directory structure:

- `src`: This directory contains the source code for the project.
  - `main.py`: This file is the entry point of the application. It creates an instance of the Flask app and sets up the routes.
  - `routes.py`: This file exports a function `test_route` which handles the `/test` route of the application. It returns the string "Hello, world!".
- `tests`: This directory contains the unit tests for the project.
  - `test_main.py`: This file contains a unit test for the `main.py` file. It tests that the Flask app is created successfully.
  - `test_routes.py`: This file contains a unit test for the `routes.py` file. It tests that the `/test` route returns the string "Hello, world!".
- `sonar-project.properties`: This file is the configuration file for SonarQube. It specifies the project key, name, and version, as well as the source directories and test directories.
- `requirements.txt`: This file lists the dependencies for the project.
- `.coveragerc`: This file is the configuration file for coverage.py. It specifies the source directories and the options for coverage reporting.
- `Dockerfile`: This file is used to build a Docker image for the project. It specifies the base image, copies the source code, installs the dependencies, and sets the entry point.
- `docker-compose.yml`: This file is used to define the Docker containers for the project. It specifies the services, networks, and volumes.
- `prometheus.yml`: This file is the configuration file for Prometheus. It specifies the targets and the metrics to scrape.
- `Makefile`: This file contains the commands for building, testing, and running the project.
- `README.md`: This file contains the documentation for the project.

## Contributing

If you would like to contribute to this project, please fork the repository and submit a pull request.