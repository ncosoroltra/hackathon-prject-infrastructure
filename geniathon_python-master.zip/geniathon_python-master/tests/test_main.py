import main

def test_flask_app():
    app = main.create_app()
    assert app is not None