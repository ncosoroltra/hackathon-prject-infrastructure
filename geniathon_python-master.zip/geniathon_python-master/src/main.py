from flask import Flask
from routes import test_route
from prometheus import metrics

app = Flask(__name__)

# Register routes
app.add_url_rule('/test', 'test', test_route)
app.add_url_rule('/actuator/prometheus', 'prometheus', metrics)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)