from flask import Flask
from flask import Response
import configparser
from prometheus_utils.customExposition import custom_exposition
from prometheus_client import CONTENT_TYPE_LATEST, REGISTRY

app = Flask(__name__)

# Read the configuration file
config = configparser.ConfigParser()
config.read('./config.ini')

# Get the values from the configuration file
service_name = config.get('PROMETHEUS', 'service_name')
language = config.get('PROMETHEUS', 'language')
development_type = config.get('PROMETHEUS', 'development_type')

my_exposition = custom_exposition()

@app.route('/actuator/prometheus')
def metrics():   
     # Generate the Prometheus response
    response = my_exposition.generate_latest(REGISTRY, service_name, language, development_type)
    return Response(response, mimetype=CONTENT_TYPE_LATEST)