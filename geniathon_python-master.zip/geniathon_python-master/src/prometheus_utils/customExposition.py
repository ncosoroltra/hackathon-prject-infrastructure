from prometheus_client.core import REGISTRY
from prometheus_client.utils import floatToGoString

class custom_exposition:

    @staticmethod
    def generate_latest(registry = REGISTRY, service_name = 'master', language = 'python', development_type='manual'):
        """Returns the metrics from the registry in latest text format as a string."""

        def sample_line(line, service_name, language, development_type):
            if line.labels:
                    labelstr = '{{{0},serviceName="{1}", language="{2}", developmentType="{3}"}}'.format(','.join(
                        ['{0}="{1}"'.format(
                            k, v.replace('\\', r'\\').replace('\n', r'\n').replace('"', r'\"'))
                            for k, v in sorted(line.labels.items())]), service_name, language, development_type)
            else:
                labelstr = '{{serviceName="{0}", language="{1}", developmentType="{2}"}}'.format(service_name, language, development_type)
            
            timestamp = ''
            if line.timestamp is not None:
                # Convert to milliseconds.
                timestamp = ' {0:d}'.format(int(float(line.timestamp) * 1000))
            return '{0}{1} {2}{3}\n'.format(
                line.name, labelstr, floatToGoString(line.value), timestamp)

        output = []
        for metric in registry.collect():
            try:
                mname = metric.name
                mtype = metric.type
                # Munging from OpenMetrics into Prometheus format.
                if mtype == 'counter':
                    mname = mname + '_total'
                elif mtype == 'info':
                    mname = mname + '_info'
                    mtype = 'gauge'
                elif mtype == 'stateset':
                    mtype = 'gauge'
                elif mtype == 'gaugehistogram':
                    # A gauge histogram is really a gauge,
                    # but this captures the structure better.
                    mtype = 'histogram'
                elif mtype == 'unknown':
                    mtype = 'untyped'

                output.append('# HELP {0} {1}\n'.format(
                    mname, metric.documentation.replace('\\', r'\\').replace('\n', r'\n')))
                output.append('# TYPE {0} {1}\n'.format(mname, mtype))

                om_samples = {}
                for s in metric.samples:
                    for suffix in ['_created', '_gsum', '_gcount']:
                        if s.name == metric.name + suffix:
                            # OpenMetrics specific sample, put in a gauge at the end.
                            om_samples.setdefault(suffix, []).append(sample_line(s, service_name, language, development_type))
                            break
                    else:
                        output.append(sample_line(s, service_name, language, development_type))
            except Exception as exception:
                exception.args = (exception.args or ('',)) + (metric,)
                raise

            for suffix, lines in sorted(om_samples.items()):
                output.append('# HELP {0}{1} {2}\n'.format(metric.name, suffix,
                                                        metric.documentation.replace('\\', r'\\').replace('\n', r'\n')))
                output.append('# TYPE {0}{1} gauge\n'.format(metric.name, suffix))
                output.extend(lines)
        return ''.join(output).encode('utf-8')

