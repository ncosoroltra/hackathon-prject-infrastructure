package com.mycompany.myjavaapp.web;

import com.mycompany.myjavaapp.web.TestController;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class TestServiceTest {

    @Test
    void test() {
        TestController service = new TestController();
        String result = service.test();
        assertEquals("Hello, world!", result);
    }

}