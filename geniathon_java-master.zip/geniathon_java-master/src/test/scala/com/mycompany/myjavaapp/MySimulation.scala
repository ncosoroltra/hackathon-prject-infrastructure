package com.mycompany.myproject

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class MySimulation extends Simulation {
    val serviceUrl = System.getProperty("serviceUrl")
    
    val httpProtocol = http
        .baseUrl("http://" + serviceUrl)
        .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        .doNotTrackHeader("1")
        .acceptLanguageHeader("en-US,en;q=0.5")
        .acceptEncodingHeader("gzip, deflate")
        .userAgentHeader("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36")

    val scn = scenario("My Scenario")
        .exec(http("My Request")
            .get("/test"))

    setUp(
        scn.inject(
            rampUsersPerSec(1) to 10 during (10 seconds),
            constantUsersPerSec(10) during (60 seconds)
        )
    ).protocols(httpProtocol)
}